-- Prize Bond Scanner schema (SQLite 3)
-- Applied automatically on backend start. Kept here for reference and manual
-- inspection: sqlite3 database/prize_bonds.db < database/schema.sql

PRAGMA journal_mode = WAL;
PRAGMA foreign_keys = ON;

CREATE TABLE IF NOT EXISTS schema_meta (
    key TEXT PRIMARY KEY,
    value TEXT NOT NULL
);

-- One row per unique bond. serial is canonical ASCII (Bengali digits converted),
-- leading zeros preserved. UNIQUE is the hard duplicate guard.
CREATE TABLE IF NOT EXISTS bonds (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    serial TEXT NOT NULL UNIQUE,
    raw_text TEXT,
    source TEXT NOT NULL CHECK (source IN ('auto', 'manual')),
    confidence REAL,
    note TEXT,
    created_at TEXT NOT NULL,
    updated_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_bonds_created_at ON bonds (created_at DESC);

-- Every processed camera frame that was not skipped as an identical repeat.
-- bond_id is written at scan time and survives later serial corrections.
CREATE TABLE IF NOT EXISTS scan_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    serial TEXT,
    bond_id INTEGER REFERENCES bonds (id) ON DELETE SET NULL,
    status TEXT NOT NULL CHECK (
        status IN ('saved', 'duplicate', 'uncertain', 'failed')
    ),
    confidence REAL,
    raw_text TEXT,
    reason TEXT,
    image_path TEXT,
    processing_ms INTEGER,
    variants TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_attempts_created_at ON scan_attempts (created_at DESC);
CREATE INDEX IF NOT EXISTS idx_attempts_status ON scan_attempts (status);

-- Duplicate presentations, tracked separately for the dashboard.
CREATE TABLE IF NOT EXISTS duplicate_attempts (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    serial TEXT NOT NULL,
    bond_id INTEGER REFERENCES bonds (id) ON DELETE SET NULL,
    confidence REAL,
    raw_text TEXT,
    created_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_duplicates_created_at ON duplicate_attempts (created_at DESC);

-- Audit trail for manual fixes of OCR results.
CREATE TABLE IF NOT EXISTS corrections (
    id INTEGER PRIMARY KEY AUTOINCREMENT,
    bond_id INTEGER NOT NULL REFERENCES bonds (id) ON DELETE CASCADE,
    old_serial TEXT NOT NULL,
    new_serial TEXT NOT NULL,
    old_confidence REAL,
    note TEXT,
    corrected_at TEXT NOT NULL
);
CREATE INDEX IF NOT EXISTS idx_corrections_bond ON corrections (bond_id);
